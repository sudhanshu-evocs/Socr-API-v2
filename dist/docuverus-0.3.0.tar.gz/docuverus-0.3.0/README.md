# Introduction
SOCR Revamp

# Getting Started
1.	Installation process
- See CI/CD for socr_revamp below
2.	Software dependencies
- Runtime package dependencies are defined in `pyproject.toml`; development and service dependencies are listed in `src/requirements.txt`.

# Build, Install, and Test

## Building the Python package

The package metadata and build configuration are defined in `pyproject.toml`. Use Python 3.12 or newer:

```bash
python -m pip install --upgrade build
python -m build
```

This creates the distributable artifacts in `dist/`:

- `docuverus-<version>.tar.gz` — source distribution
- `docuverus-<version>-py3-none-any.whl` — wheel distribution

To install the wheel locally after building:

```bash
python -m pip install dist/docuverus-*.whl
```

To install the project in editable mode during development:

```bash
python -m pip install -e .
```

## Testing

Run pytest from the repository root:

```bash
pytest
```

# Contribute
Keep this file up to date if you change how things work.

# CI/CD for socr_revamp
## Docker
docker compose build
docker compose up

docker run -it socr_revamp-app bash -c "cd test_suite && pytest"

## Virtual Environments
### Creating and Activating (Windows)
```bash
python -m venv venv
venv\Scripts\activate.bat
```

## PIP and dependency management
### Installing dependencies
```bash
pip install -r src/requirements.txt
```

## Pre-commit hooks
### Installing pre-commit:
```bash
pip install pre-commit
pre-commit install
```
### Running pre-commit hooks manually on all files (for first use, or to see changes before committing):
```bash
pre-commit run --all-files
```

## Testing
### Running tests
```bash
pytest
```

### Running legacy metadata converter tests
```bash
pytest scripts/tests/test_LegacyMetadataConverter.py
```

### Converting legacy to new - step by step
* Run python3 ./scripts/convert_legacy_metadata_to_rulesets.py

### Comparing generated rulesets to canonical TemplateJson rulesets
* Run `python3 ./scripts/compare_generated_rulesets.py`
* Review the terminal summary and `scripts/generated_rulesets/comparison_report.json`

### Standardizing canonical TemplateJson formatting
* Run `python3 ./scripts/standardize_template_json.py --dry-run`
* Review the terminal summary, then rerun without `--dry-run` to rewrite `src/docuverus/RuleEvaluators/TemplateJson` into canonical diff-friendly formatting

### Applying targeted TemplateJson updates from the comparison report
* Run `python3 ./scripts/apply_ruleset_updates_from_report.py --comparison-report ./scripts/generated_rulesets/comparison_report.json --dry-run`
* Review the terminal summary and `scripts/generated_rulesets/template_update_report.json`
* Run the standardizer after applying updates if you want to reconfirm the reference corpus is still in canonical formatting
* Rerun without `--dry-run` to write targeted updates into `src/docuverus/RuleEvaluators/TemplateJson`

## Immediate TODOs
* Need to get rid of TemplateJson/Generic
* 
